
DROP TABLE IF EXISTS `races`;
CREATE TABLE IF NOT EXISTS `races` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `U_w3rac_Code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `races` (`id`, `code`, `name`) VALUES
(1, 'humans', 'Humains'),
(2, 'nightelfs', 'Elfes de la nuit'),
(3, 'orcs', 'Orcs'),
(4, 'undeads', 'Morts vivants'),
(5, 'neutrals', 'Neutres');
