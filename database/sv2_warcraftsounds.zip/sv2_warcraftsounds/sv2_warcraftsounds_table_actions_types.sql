
DROP TABLE IF EXISTS `actions_types`;
CREATE TABLE IF NOT EXISTS `actions_types` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `U_act_Code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `actions_types` (`id`, `code`, `name`) VALUES
(1, 'ready', 'Prêt !'),
(2, 'warcry', 'Cri de guerre'),
(3, 'what', 'What ?'),
(4, 'yes', 'Oui ?'),
(5, 'attack', 'Attaque'),
(6, 'fun', 'Fun'),
(7, 'death', 'Mort');
