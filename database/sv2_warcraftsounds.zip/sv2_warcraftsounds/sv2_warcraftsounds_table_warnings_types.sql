
DROP TABLE IF EXISTS `warnings_types`;
CREATE TABLE IF NOT EXISTS `warnings_types` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` varchar(25) NOT NULL,
  `name` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `U_w3war_Code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `warnings_types` (`id`, `code`, `name`) VALUES
(1, 'cannotbuildthere', 'cannotbuildthere'),
(2, 'goldminelow', 'goldminelow'),
(3, 'goldminecollapsed', 'goldminecollapsed'),
(4, 'nofood', 'nofood'),
(5, 'noenergy', 'noenergy'),
(6, 'nogold', 'nogold'),
(7, 'nolumber', 'nolumber'),
(8, 'inventoryfull', 'inventoryfull'),
(9, 'townattack', 'townattack'),
(10, 'unitattack', 'unitattack'),
(11, 'herodies', 'herodies'),
(12, 'allytownattack', 'allytownattack'),
(13, 'allyattack', 'allyattack'),
(14, 'allyherodies', 'allyherodies'),
(15, 'buildingcomplete', 'buildingcomplete'),
(16, 'upgradecomplete', 'upgradecomplete'),
(17, 'researchcomplete', 'researchcomplete'),
(18, 'placedoffblight', 'placedoffblight'),
(19, 'mining', 'mining');
