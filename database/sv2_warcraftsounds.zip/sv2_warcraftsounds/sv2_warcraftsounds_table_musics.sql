
DROP TABLE IF EXISTS `musics`;
CREATE TABLE IF NOT EXISTS `musics` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `k_race` int(11) UNSIGNED DEFAULT NULL,
  `code` varchar(20) NOT NULL,
  `name` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `U_w3mus_RaceCode` (`k_race`,`code`),
  KEY `FK_w3mus_Race` (`k_race`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `musics` (`id`, `k_race`, `code`, `name`, `url`) VALUES
(1, 1, 'theme1', 'Thème 1', '/sounds/humans/musics/theme1.mp3'),
(2, 1, 'theme2', 'Thème 2', '/sounds/humans/musics/theme2.mp3'),
(3, 1, 'theme3', 'Thème 3', '/sounds/humans/musics/theme3.mp3'),
(4, 3, 'theme1', 'Thème 1', '/sounds/orcs/musics/theme1.mp3'),
(5, 3, 'theme2', 'Thème 2', '/sounds/orcs/musics/theme2.mp3'),
(6, 3, 'theme3', 'Thème 3', '/sounds/orcs/musics/theme3.mp3'),
(7, 2, 'theme1', 'Thème 1', '/sounds/nightelfs/musics/theme1.mp3'),
(8, 2, 'theme2', 'Thème 2', '/sounds/nightelfs/musics/theme2.mp3'),
(9, 2, 'theme3', 'Thème 3', '/sounds/nightelfs/musics/theme3.mp3'),
(10, 4, 'theme1', 'Thème 1', '/sounds/undeads/musics/theme1.mp3'),
(11, 4, 'theme2', 'Thème 2', '/sounds/undeads/musics/theme2.mp3'),
(12, 4, 'theme3', 'Thème 3', '/sounds/undeads/musics/theme3.mp3'),
(13, 1, 'defeat', 'Défaite', '/sounds/humans/musics/defeat1.mp3'),
(14, 1, 'victory', 'Victoire', '/sounds/humans/musics/victory1.mp3'),
(15, 2, 'defeat', 'Défaite', '/sounds/nightelfs/musics/defeat1.mp3'),
(16, 2, 'victory', 'Victoire', '/sounds/nightelfs/musics/victory1.mp3'),
(17, 3, 'defeat', 'Défaite', '/sounds/orcs/musics/defeat1.mp3'),
(18, 3, 'victory', 'Victoire', '/sounds/orcs/musics/victory1.mp3'),
(19, 4, 'defeat', 'Défaite', '/sounds/undeads/musics/defeat1.mp3'),
(20, 4, 'victory', 'Victoire', '/sounds/undeads/musics/victory1.mp3');
